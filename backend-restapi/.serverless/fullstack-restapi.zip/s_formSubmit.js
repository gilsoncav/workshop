var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'jetpax',
applicationName: 'workshop',
appUid: 'rvYS0jpn2mwJxNPD58',
orgUid: 'TnPQGJ7107fKPgRxjr',
deploymentUid: '38193378-8769-4dcf-83a1-3484270a9883',
serviceName: 'fullstack-restapi',
shouldLogMeta: true,
stageName: 'dev',
pluginVersion: '3.4.1'})
const handlerWrapperArgs = { functionName: 'fullstack-restapi-dev-formSubmit', timeout: 10}
try {
  const userHandler = require('./index.js')
  module.exports.handler = serverlessSDK.handler(userHandler.submit, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
